package com.capg.project.service;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import javax.security.auth.login.AccountLockedException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.project.entity.BillDetails;
import com.capg.project.repository.IBillDetailsRepository;

@Service 
public class BillDetailsService implements IBillDetailsService{
@Autowired
IBillDetailsRepository billDetailsRepository;

@Override
public BillDetails viewBillAccount(BigInteger billNumber) {
	BillDetails accountDetails=null;
	try {
			System.out.println("see the details"+billDetailsRepository.existsById(billNumber));
			accountDetails=billDetailsRepository.findById(billNumber).get();
		}
	catch(Exception e) 
		{
			e.printStackTrace();
		}
	return accountDetails;
}

@Override
public List<BillDetails> viewAllBillAccounts() {
	List<BillDetails> allAccountDetails=new ArrayList<BillDetails>();
	try {
			allAccountDetails=billDetailsRepository.findAll();
		}
	catch(Exception e) 
		{
			e.printStackTrace();
		}
	return allAccountDetails;
} 

//@Override
//public boolean deleteBillAccount(BigInteger billNumber) {
	//boolean deleteFlag=false;
	//try {
		//	billDetailsRepository.deleteAccountByNo(billNumber);
		//}
	//catch(Exception e)
		//{
			//e.printStackTrace();
			//deleteFlag=true;
		//}
	//return deleteFlag;
//}

@Override
public void save(BillDetails billdetails) {
	try {
	billDetailsRepository.save(billdetails);
	}
	catch(Exception e) 
	{
		e.printStackTrace();
	}
	System.out.println("dev");

	
}


}
