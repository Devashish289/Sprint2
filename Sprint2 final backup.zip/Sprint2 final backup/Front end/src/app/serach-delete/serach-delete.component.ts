import { Component, OnInit } from '@angular/core';
import { UserRegistationService } from '../user-registation.service';
import { BillDetails } from '../BillDetails';

@Component({
  selector: 'app-serach-delete',
  templateUrl: './serach-delete.component.html',
  styleUrls: ['./serach-delete.component.css']
})
export class SerachDeleteComponent implements OnInit {

  BillDetails:any =  new BillDetails();
  billNo:number;
  
  constructor(private service:UserRegistationService) { }


//public delete(id:number){
 //let resp= this.service.deleteBillDetails(id);
 //resp.subscribe((data)=>this.BillDetails=data);
//}

public Search(){
  let resp= this.service.viewAccountById(this.billNo);
  resp.subscribe((data)=>this.BillDetails=data);
 }
 public Paybill(){
   let resp=this.service.paynow();
 }

  ngOnInit() {
  }

}
